var topNavLink = document.getElementsByClassName("top_nav-link");
var sideNavLink = document.getElementsByClassName("side_nav-link");
//export the two variables
export {topNavLink, sideNavLink};
//explain: it gets the elements with the class name "top_nav-link" and "side_nav-link" and exports them.
