
//pages here
var links = {
  "TopNav": [
    {
      "id": "item1",
      "class": "doc_outline_sub top_nav-item top_nav-item-link",
      "content": "About Us",
      "href": "/about-us.html",
      "name": "About"
    
    },
    {
      "id": "item2",
      "class": "doc_outline_sub top_nav-item top_nav-item-link",
      "content": "Products",
      "href": "/products.html",
      "name": "Products"
    },
    {
      "id": "item3",
      "class": "doc_outline_sub top_nav-item top_nav-item-link",
      "content": "placeholder",
      "href": "/oo.html",
      "name": "Promotions"
    },
    {
      "id": "item4",
      "class": "doc_outline_sub top_nav-item top_nav-item-link",
      "content": "Greenhouse",
      "href": "/Greenhouse.html",
      "name": "Greenhouse"
    }
   
    
  ],
  "SideNav":[
            {
              "id": "item1",
              "class": "doc_outline_sub top_nav-item top_nav-item-link",
              "content": "Directors",
              "href": "/Directors.html",
              "name": "Directors"
            },
            {
              "id": "item2",
              "class": "doc_outline_sub top_nav-item top_nav-item-link",
              "content": "More Info",
              "href": "/Directors.html",
              "name": "AAAAAAA"
            },
            {
              "id": "item3",
              "class": "doc_outline_sub top_nav-item top_nav-item-link",
              "content": "How about that?",
              "href": "/Director.html",
              "name": "AAAAAAA"
            }
  ],
  "Other (TBD)": {"TBD": "/TBD.html"}
}
//export links
export default links;
